using UnityEngine;
//using System.Collections;
//
//public class DroneNav : StateMachineBehaviourEx {
//
//	#region 
//	public enum SheepStates 
//	{
//		Flocking,
//		Resting,
//		Escaping
//	}
//	#endregion
//
//
//	public SwarmNav Swarm;
//	public float PlayerDistance = 2f;
//
//	NavMeshAgent _navigation;
//	Transform _transform;
//	Transform _player;
//	bool hasPath;
//
//	void Start() {
//		_transform = transform;
//
//		_navigation = GetComponent<NavMeshAgent>();
//
//		_player = GameObject.FindGameObjectWithTag("Player").transform;
//
//		hasPath = false;
//
//		// start to flock
//		currentState = SheepStates.Flocking;
//	}
//
//
//	// STATES
//
//	#region State Flocking
//	IEnumerator Flocking_EnterState() {
//
//		// start walking animation
//		animation.CrossFade("walk");
//		_navigation.speed = 0.5f;
//		animation ["walk"].speed = Mathf.Clamp(_navigation.speed * 1.15f, 0, 1);
//
//		// resume navigation
//		_navigation.Resume ();
//
//		while (true) {
//
//			// check to calculate new path
//			if (hasPath && _navigation.remainingDistance < _navigation.stoppingDistance) {
//				hasPath = false;
//			}
//
//			// check if path is null then calculate new path
//
//			if (!hasPath) {
//				var randomPosition = Swarm.WorldTargets[Random.Range(0, Swarm.WorldTargets.Length)];
//
//				NavMeshPath path = new NavMeshPath ();
//				_navigation.CalculatePath (randomPosition, path);
//
//				if (path.status == NavMeshPathStatus.PathComplete) {
//					_navigation.path = path;
//					hasPath = true;
//				} 
//			}
//
//			// check if we need to flee from the player, if yes we switch states
//			if (IsPlayerClose ()) {
//				currentState = SheepStates.Escaping;
//				break;
//			}
//
//			// we may decide randomly to rest
//			var test = Random.Range(0, 10000);
//			if (test > 110 && test < 250) 
//			{
//				currentState = SheepStates.Resting;
//				break;
//			}
//
//			yield return new WaitForEndOfFrame();
//		}
//	}
//	#endregion
//
//	#region State Resting
//	IEnumerator Resting_EnterState() {
//
//		_navigation.Stop ();
//
//		var time = Random.Range(3, 6);
//		var elapsed = 0f;
//
//		// crossfade the animation
//		animation.CrossFade("idle1");
//
//		// during our rest we have to still check if player is close to us
//		while (elapsed < time) {
//			if (IsPlayerClose ()) {
//				currentState = SheepStates.Escaping;
//				break;
//			}
//			elapsed += Time.fixedDeltaTime;
//
//			yield return null;
//		}
//		// switch back to flocking
//		currentState = SheepStates.Flocking;
//	}
//	#endregion
//
//	#region State Escaping
//	IEnumerator Escaping_EnterState() {
//
//		animation ["walk"].speed = 1.5f;
//		_navigation.speed = 3f;
//
////		Vector3 target = _navigation.destination;
////		float distance;
////		float lastDistance = float.MinValue;
//
//		while (true) {
//
////			// find target which is closest to sheep and further from approach distance
////			distance = int.MaxValue;
////
////			foreach (var tg in Swarm.WorldTargets) {
////				if (Vector3.Distance (tg, _transform.position) > PlayerDistance && 
////				    Vector3.Distance (tg, _transform.position) < distance) {
////					distance = Vector3.Distance (tg, _transform.position);
////					target = tg;
////				}
////			}
////
////			// if the current distance is bigger than last one we recalculate path
////			if (target != _navigation.destination) {
////				_navigation.destination = target;
////			}
//
//			if (_navigation.remainingDistance < _navigation.stoppingDistance) {
//				_navigation.destination = Swarm.WorldTargets [Random.Range (0, Swarm.WorldTargets.Length)];
//			}
//
//			// check if we are far away from player, return to flocking
//			if (!IsPlayerClose ()) {
//				currentState = SheepStates.Flocking;
//				break;
//			}
//			yield return null;
//		}
//	}
//	#endregion
//
//	// PRIVATE METHDS
//
//	#region Helper methods
//	private bool IsPlayerClose() {
//		var playerDist = Vector3.Distance(_transform.position, _player.position);
//
//		return (playerDist < PlayerDistance);
//	}
//	#endregion
//}
