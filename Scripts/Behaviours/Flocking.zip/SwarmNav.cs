using UnityEngine;
//using System.Collections;
//
//public class SwarmNav : MonoBehaviour {
//
//	public GameObject Drone;
//	public float Radius;
//	public int Drones;
//
//	public int TargetCount = 0;
//	public Vector2[] Targets;
//
//	public Vector3[] WorldTargets;
//
//	// Use this for initialization
//	void Start () {
//		for (int i = 0; i < Drones; i++) {
//			var droneTemp = (GameObject) GameObject.Instantiate(Drone);
//			DroneNav db = droneTemp.GetComponent<DroneNav>();
//			db.Swarm = this;
//
//			// spawn inside circle
//			Vector2 pos = new Vector2(transform.position.x, transform.position.z) + Random.insideUnitCircle * Radius;
//			droneTemp.transform.position = new Vector3(pos.x, transform.position.y, pos.y);
//			droneTemp.transform.parent = transform;
//		}
//
//		// now setup targets
//		if (TargetCount > 0) {
//			Targets = new Vector2[TargetCount];
//			for (var i=0; i<TargetCount; i++) {
//				var vect = Random.insideUnitCircle * Radius;
//				Targets [i] = new Vector3 (vect.x, vect.y);
//			}
//		}
//
//		WorldTargets = new Vector3[Targets.Length];
//		for (var i=0; i< WorldTargets.Length; i++) {
//			WorldTargets [i] = new Vector3 (
//				transform.position.x + Targets[i].x, 
//				transform.position.y, 
//				transform.position.z + Targets[i].y);
//		}
//	}
//	
//
//	protected virtual void OnDrawGizmosSelected()
//	{
//		Gizmos.color = Color.green;
//		Gizmos.DrawWireSphere (transform.position, Radius);
//
//		if (Targets != null) {
//			Gizmos.color = Color.blue;
//			foreach (var target in Targets) {	
//				var targ3 = new Vector3 (target.x, 0, target.y);
//				Gizmos.DrawSphere (transform.position + targ3, 0.3f);
//			}
//		}
//	}
//
//}
